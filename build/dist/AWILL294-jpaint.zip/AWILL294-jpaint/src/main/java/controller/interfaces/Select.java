package controller.interfaces;

import java.util.List;
import model.interfaces.Shape;

public interface Select {

  List<Shape> getList();

}
