/*
 * Assignment: 1
 * Topic: JPaint
 * Author: Jeffrey Sharpe
 */
package model;

public enum ShapeType {
    ELLIPSE,
    RECTANGLE,
    TRIANGLE
}
